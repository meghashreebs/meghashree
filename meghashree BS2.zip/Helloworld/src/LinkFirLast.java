import java.util.LinkedList;

public class LinkFirLast {
	public static void main(String[] args)
	{
		LinkedList<String> linkedList = new LinkedList<>();

	// Inserting
	linkedList.add("red");
	linkedList.add("green");
	linkedList.add("orange");
	linkedList.add("white");
	
	 linkedList.addFirst("Black");
	 
	  
	  linkedList.addLast("Pink");
	     
	  System.out.println("Final linked list:" + linkedList);  
	
	}

}

import java.util.Iterator;
import java.util.LinkedList;

public class LinkListReverse {

	public static void main(String[] args)
	{
		LinkedList<String> linkedList = new LinkedList<>();

	// Inserting
	linkedList.add("red");
	linkedList.add("green");
	linkedList.add("orange");
	linkedList.add("white");
	
	
	Iterator<String> iterator = linkedList.descendingIterator();
	  
    
    while (iterator.hasNext()) 
    {
        System.out.println(iterator.next());
    }
	}
}

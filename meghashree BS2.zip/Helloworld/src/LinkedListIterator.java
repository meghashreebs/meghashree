

	// Java program for iterating the LinkedList
	// using For loop

	import java.util.LinkedList;

	public class LinkedListIterator {
		public static void main(String[] args)
		{

			// Creating a LinkedList 
			LinkedList<String> linkedList = new LinkedList<>();

			// Inserting
			linkedList.add("red");
			linkedList.add("green");
			linkedList.add("orange");
			linkedList.add("white");
			

			System.out.print("Iterating the LinkedList using a simple for loop : " +"\n");

			for (int i = 0; i < linkedList.size(); i++) {
				System.out.print(linkedList.get(i) + "\n ");
			}

			
		}
	}




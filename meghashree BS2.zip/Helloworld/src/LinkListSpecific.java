import java.util.LinkedList;
import java.util.Iterator;

public class LinkListSpecific {
	public static void main(String[] args)
	{
		LinkedList<String> linkedList = new LinkedList<>();

	// Inserting
	linkedList.add("red");
	linkedList.add("green");
	linkedList.add("orange");
	linkedList.add("white");
	
	Iterator p = linkedList.listIterator(2);

	   // print list from second position
	   while (p.hasNext()) {
	   System.out.println(p.next());
	   }
	
}

}

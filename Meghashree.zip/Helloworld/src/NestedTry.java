
public class NestedTry {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		try {
			int s[] = {1,2,3,4,5};
			System.out.println(s[5]);
			try {
				int x=s[2]/0;
				
			}
			catch(ArithmeticException e2) {
				System.out.println("div by zero is not possible");
				
			}
		}
		catch(ArrayIndexOutOfBoundsException e1) {
			System.out.println("element at such index does not exist");
		}

	}

}

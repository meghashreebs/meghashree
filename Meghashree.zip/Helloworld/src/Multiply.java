import java.util.Scanner;

public class Multiply {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		System.out.println("enter the  1st number");
		int a = sc.nextInt();
		System.out.println("enter the 2nd number");
		int b = sc.nextInt();
		int mul;
		System.out.println(" mul=" +( a*b));
	}

}

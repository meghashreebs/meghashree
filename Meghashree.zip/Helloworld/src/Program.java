


	
    class Program
    {
    	 public static void main(String[] args)
        {
        	
        			
        	Degree D= new Degree();
        	Undergraduate d2 = new Undergraduate();
        	Postgraduate d3 = new Postgraduate();

        	D.getDegree();
        	d2.getDegree();
        	D.getDegree();
        	d3.getDegree();
        	 
        	
        	
        	
        }
            
    }      
            
            
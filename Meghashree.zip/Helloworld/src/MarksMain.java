
public class MarksMain {
	

	

	public static void main(String[] args) {

	    A a = new A(70, 50, 100);

	       System.out.println(a.getPercentage());

	       B b = new B(90, 75, 64, 86);

	       System.out.println(b.getPercentage());

	}

	}



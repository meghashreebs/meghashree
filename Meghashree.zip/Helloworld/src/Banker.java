

	abstract class Banker {

		abstract int getBalance();

		}

		class BankA extends Banker {

		private int balance;

		void deposit(int money) {

		balance += money;

		}

	

		int getBalance() {

		return balance;

		}

		}

		class BankB extends Banker {

		private int balance;

		void deposit(int money) {

		balance += money;

		}

		

		int getBalance() {

		return balance;

		}

		}

		class BankC extends Banker {

		private int balance;

		void deposit(int money) {

		balance += money;

		}

		

		int getBalance() {

		return balance;

		}

		}


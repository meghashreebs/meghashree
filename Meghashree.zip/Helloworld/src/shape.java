import java.lang.Math;
public abstract class shape {
	abstract void area();
	double area;
}
class Square extends shape{
	double side=20;
	void area()
	{
		area=side*side;
		System.out.println("area of square: " +area);
		
	}
}

class Rectangle extends shape{
	double w=10,h=30;
	void area()
	{
		area=w*h;
		System.out.println("area of rectangle: " +area);
		
	}
}

class Circle extends shape{
	double r=30;
	void area()
	{
		area=Math.PI*r*r;
		System.out.println("area of circle: " +area);
		
	}
}



	


public class Area1 {
	public static void main(String[] args)
	{
		Square S=new Square();
		Rectangle R=new Rectangle();
		Circle C= new  Circle();
		
		S.area();
		R.area();
		C.area();
	}

}

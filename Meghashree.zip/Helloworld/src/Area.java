import java.util.Scanner;

public class Area {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		
		float b = sc.nextInt();
		float h=sc.nextInt();
		float area = ( b*h) / 2 ;
		System.out.println("Area of Triangle is: "+area);
	}

}

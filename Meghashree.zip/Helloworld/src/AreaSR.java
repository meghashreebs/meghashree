
public class AreaSR {
	
	public static void output(int l, int b)
	    {
	        System.out.println("Area of Rectangle is = " + (l*b));
	    }

	   public static  void output(int a)
	    {
	        System.out.println("Area of Square is = " +(a*a));
	    }
	

	public static void main(String[] args)
	{
	    AreaSR obj = new AreaSR();
	    obj.output(5,6);
	    obj.output(5);
	}               


}

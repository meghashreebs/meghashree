
public class Ascii {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ch='A';
		int ascii= ch;
		
		System.out.println("ascii value=" +ascii);
		}

}

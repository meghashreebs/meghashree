import java.util.Scanner;

public class Pos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc=new Scanner(System.in);
		
		int num = sc.nextInt();
		if(num>0)
			System.out.println("num is positive");
		else
			System.out.println("num is negative");
		
	}

}

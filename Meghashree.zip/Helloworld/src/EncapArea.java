
 class EncapArea {

private  int side, rad;




public  int getSide() {
	return side;
	
	
}
public void setSide(int side)
{
	this.side= side;
}


}


public class Clock {
	
	   int hours;  //store hours
	   int minutes; //store minutes
	   int seconds; //store seconds

	    
	    public Clock(int h, int m, int s)
	    {
		   hours=h;
		   minutes=m;
		   seconds=s;
		     
	    }
	         
	   

	  
	    public void setTime()
	    {
		      if(0 <= hours && hours < 24 && 0 <= minutes && minutes < 60 && 0 <= seconds && seconds < 60)
		    	  System.out.println("time is valid");
		      else
		    	  System.out.println("time is invalid");
	    }
	    public void setTimemode()
	    {
	    	
		      if(hours>=12 && hours<24)
		      {
		    	  System.out.println("time is : " +hours+ ":" +minutes+ ":" +seconds+"PM");
		    	  
		      }
		      else {
		    	  System.out.println("time is : " +hours+ ":" +minutes+ ":" +seconds+"AM");
		      }
	    }
	    
	  
	   


	public static void main(String[] args) {
		
		Clock c1= new Clock(23,19,6);
		
		c1.setTime();
		c1.setTimemode();
		

	}

}

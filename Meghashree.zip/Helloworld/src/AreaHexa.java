import java.util.Scanner;
	public class AreaHexa {

	 public static void main(String[] args) {
	  Scanner cs=new Scanner(System.in);
	  System.out.println("Enter the length of the side:");
	     int a=cs.nextInt();
	     double area=(3*Math.sqrt(3)*Math.pow(a,2))/2.0;
	     
	     System.out.println("Area of the Hexagon = "+area);
	     
	  
	 }
	}



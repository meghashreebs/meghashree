
public class PrintNum {
	public static void printn(int a) {
		System.out.println(a);
	}
	public static void printn(float a) {
		System.out.println(a);
	}
	public  static void printn(double a) {
		System.out.println(a);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     PrintNum P= new PrintNum();
     P.printn(20.0);
	}

}

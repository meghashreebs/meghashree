
public class PrintIC {
	public static void NumChar(int n, char c) {
		System.out.println("int is: " +n + "  char is: " +c);
		
	}
	public static void NumChar( char c,int n) {
		System.out.println("char is: " +c + "   int is: " +n);
		
		
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PrintIC PIC= new PrintIC();
		PIC.NumChar(10, 'a');
		PIC.NumChar('a',10);
		

	}

}

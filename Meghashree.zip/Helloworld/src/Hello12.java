
public class Hello12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a,b,sum,mul,diff,div;
		a=10;
		b=20;
		System.out.println("sum=" +(a+b)+","+  "mul=" +(a*b)+","+ "diff=" +(a-b)+","+  "div=" +(a/b) );
		

	}

}
